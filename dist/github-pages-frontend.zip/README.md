# Nutrient calculator: GitHub Pages interface

This repository contains the browser interface. The Python calculator is
deployed separately; no optimizer code is included here.

## Publish

1. Deploy the complete Python project from its private repository.
2. In that service, set CORS_ORIGINS to https://YOUR-ACCOUNT.github.io
   (use your real account; exclude the repository path and trailing slash).
3. In this repository, open Settings > Secrets and variables > Actions >
   Variables and add API_BASE_URL with the backend HTTPS origin, for example
   https://my-calculator.onrender.com. Exclude /api/calculate.
4. Open Settings > Pages and choose GitHub Actions as the publishing source.
5. Push to main, or run Publish calculator frontend from Actions manually.
6. Open the Pages URL and click Calculate additions. If you later change the
   repository variable, run the workflow again to update the deployed files.

The address in config.js is public configuration. The workflow generates it
from API_BASE_URL during deployment. Do not put secrets in frontend files.

The calculator uses ionic species (NO3, K, Ca, Mg, SO4, H2PO4) in mg/L and
assumes pure anhydrous fertilizer salts. Stock strengths are g of fertilizer
per L of stock. It models additions to a fixed working volume, not dilution.

Use a trusted hosting service for the API and retain the private backend's
complete project and instructions. The Pages workflow publishes frontend/
only and does not install or run the backend.
